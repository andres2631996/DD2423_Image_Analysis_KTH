function [linepar,acc,outcurves] = ...
houghline(curves, magnitude, ...
nrho, ntheta, threshold, nlines, verbose,vote)


[xsize,ysize]=size(magnitude);
if nargin<2 || nargin>8
    disp('Wrong number of arguments')
elseif nargin==2
    nrho=sqrt(xsize^2+ysize^2);
    ntheta=180;
    threshold=0;
    nlines=5;
    verbose=0;
    vote=0;
elseif nargin==3
    ntheta=180;
    threshold=0;
    nlines=5;
    verbose=0;
    vote=0;
elseif nargin==4
    threshold=0;
    nlines=5;
    verbose=0;
    vote=0;
elseif nargin==5
    nlines=5;
    verbose=0;
    vote=0;
elseif nargin==6
    verbose=0;
    vote=0;
elseif nargin==7
    vote=0;
elseif (nrho<1) || (ntheta<1) || (vote~=0 && vote~=1) || nlines<1
    disp('There is some value introduced wrong');
end

if verbose==1
    % Display curves
    figure, overlaycurves(magnitude,curves),title('Edge image')
end
curves=thresholdcurves(curves,magnitude-threshold);
if verbose==2
    % Display curves and threshold
    figure
    subplot(1,3,1),overlaycurves(magnitude,curves),title('Edge image')
    subplot(1,3,2),histogram(magnitude),title('Histogram of gradient')
    subplot(1,3,3),overlaycurves(magnitude,curves),title(strcat('Edge image with threshold=',num2str(threshold)))
end
[xsize,ysize]=size(magnitude);
rho=-round(sqrt(xsize^2 + ysize^2)):ceil(2*sqrt(xsize^2 + ysize^2)/nrho):round(sqrt(xsize^2 + ysize^2))-1;
theta=-90:ceil(180/ntheta):89;


acc=zeros(nrho,ntheta);

trypointer = 1;
numcurves = 0;

while trypointer<=size(curves,2)
    polylength = curves(2, trypointer);
    numcurves = numcurves + 1;
    trypointer = trypointer + 1;
    for polyidx = 1 : polylength
        xcurve = curves(2, trypointer);
        ycurve = curves(1, trypointer);
        trypointer = trypointer + 1;
        
 
        for i=1:length(theta)
            for j=1:length(xcurve)
                rhos=xcurve*cosd(theta(i))+ycurve*sind(theta(i));
                [dummy,rho_pos]=min(abs(rho-rhos));
                if vote==0
                    delta_S = 1;
                elseif vote==1
                    delta_S=(magnitude(round(xcurve),round(ycurve))-min(magnitude(:)))/(max(magnitude(:))-min(magnitude(:)));
                end
                acc(rho_pos,i)=acc(rho_pos,i)+delta_S;
            end
        end
    end
end
% smoothen the histogram
acc = binsepsmoothiter(acc,0,10);

if verbose==3
    % Display curves, threshold and accumulator space
    figure
    subplot(2,2,1),overlaycurves(magnitude,curves),title('Edge image')
    subplot(2,2,2),histogram(magnitude),title('Histogram of gradient')
    subplot(2,2,3),overlaycurves(magnitude,curves),title(strcat('Edge image with threshold=',num2str(threshold)))
    subplot(2,2,4),showgray(log(1+abs(acc))),title(strcat('Accumulator with \theta resolution= ',num2str(round(180/ntheta)),' degrees and \rho resolution=  ',num2str(round(2*sqrt(xsize^2+ysize^2)/nrho))))
end

[pos value] = locmax8(acc);
[dummy indexvector] = sort(value);
nmaxima = size(value, 1);

linepar=[];
for idx = 1:nlines
    rho_ind = rho(pos(indexvector(nmaxima - idx + 1), 1));
    theta_ind = theta((pos(indexvector(nmaxima - idx + 1), 2)));
    linepar(:, idx) = [rho_ind; theta_ind];
end


if verbose==4
    % Display accumulator space with color points representing maxima
    figure
    subplot(2,3,1),overlaycurves(magnitude,curves),title('Edge image')
    subplot(2,3,2),histogram(magnitude),title('Histogram of gradient')
    subplot(2,3,3),overlaycurves(magnitude,curves),title(strcat('Edge image with threshold=',num2str(threshold)))
    subplot(2,3,4),showgray(log(1+abs(acc))),title(strcat('Accumulator with \theta resolution=  ',num2str(round(180/ntheta)),' degrees and \rho resolution=  ',num2str(2*round(sqrt(xsize^2+ysize^2)/nrho))))
    subplot(2,3,5),showgray(log(1+abs(acc))), title(strcat('Accumulator with ',num2str(nlines),' maxima'))
    hold on
    scatter(pos(indexvector(nmaxima:(-1):nmaxima-idx+1),2),pos(indexvector(nmaxima:(-1):nmaxima-idx+1),1),'red');
    hold off
end

outcurves=[];
cont=0;
iter=0; 


    
for i=1:nlines
%     x0=linepar(1,i)*cosd(linepar(2,i));
%     y0=linepar(1,i)*sind(linepar(2,i));
%     dx=-300*sind(linepar(2,i));
%     dy=300*cosd(linepar(2,i));
% 
%     % Extract three points from each line to create a curve which represents the line
%     
%     outcurves(1, 4*(i-1) + 1) = 0; % level, not significant
%     outcurves(2, 4*(i-1) + 1) = 3; % number of points in the curve
%     outcurves(2, 4*(i-1) + 2) = x0-dx;
%     outcurves(1, 4*(i-1) + 2) = y0-dy;
%     outcurves(2, 4*(i-1) + 3) = x0;
%     outcurves(1, 4*(i-1) + 3) = y0;
%     outcurves(2, 4*(i-1) + 4) = x0+dx;
%     outcurves(1, 4*(i-1) + 4) = y0+dy;

    
    if sind(linepar(2,i))==1
        x0=0;
        x1=size(magnitude,2)/2;
        x2=size(magnitude,2);
        y0=abs(linepar(1,i));
        y1=y0;
        y2=y0;
    elseif sind(linepar(2,i))==0
       y0=0;
       y1=size(magnitude,1)/2;
       y2=size(magnitude,1);
       x0=abs(linepar(1,i));
       x1=x0;
       x2=x0;
    else
       x0=0;
       x1=size(magnitude,2)/2;
       x2=size(magnitude,2);
       y0=(-cosd(linepar(2,i))*x0+linepar(1,i))/sind(linepar(2,i));
       y1=(-cosd(linepar(2,i))*x1+linepar(1,i))/sind(linepar(2,i));
       y2=(-cosd(linepar(2,i))*x2+linepar(1,i))/sind(linepar(2,i));
    end
    outcurves(1, 4*(i-1) + 1) = 0; % level, not significant
    outcurves(2, 4*(i-1) + 1) = 3; % number of points in the curve
    outcurves(2, 4*(i-1) + 2) = x0;
    outcurves(1, 4*(i-1) + 2) = y0;
    outcurves(2, 4*(i-1) + 3) = x1;
    outcurves(1, 4*(i-1) + 3) = y1;
    outcurves(2, 4*(i-1) + 4) = x2;
    outcurves(1, 4*(i-1) + 4) = y2;
end
end


