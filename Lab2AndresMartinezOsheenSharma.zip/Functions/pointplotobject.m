function pointplotobject(object)

pointplot(object.point)
