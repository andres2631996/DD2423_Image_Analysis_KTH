function [linepar,acc,outcurves] = ...
houghedgeline(pic, scale,gradmagnthreshold, ...
nrho, ntheta, nlines, verbose,vote)

if nargin<1 || nargin>8
    disp('Wrong number of arguments')
elseif nargin==1
    scale=1;
    gradmagnthreshold=0;
    nrho=sqrt(xsize^2+ysize^2);
    ntheta=180;
    nlines=5;
    verbose=0;
    vote=0;
elseif nargin==2
    gradmagnthreshold=0;
    nrho=sqrt(xsize^2+ysize^2);
    ntheta=180;
    nlines=5;
    verbose=0;
    vote=0;
elseif nargin==3
    nrho=sqrt(xsize^2+ysize^2);
    ntheta=180;
    nlines=5;
    verbose=0;
    vote=0;
elseif nargin==4
    ntheta=180;
    nlines=5;
    verbose=0;
    vote=0;
elseif nargin==5
    verbose=0;
    nlines=5;
    vote=0;
elseif nargin==6
    verbose=0;
    vote=0;
elseif nargin==7
    vote=0;
elseif (nrho<1) || (ntheta<1) || scale<0 || (vote~=0 && vote~=1)|| nlines<1
    disp('There is some value introduced wrong');
end

grad=Lv(pic,'Central','same',scale);
edgecurves=extractedge(pic,scale,'same',gradmagnthreshold);
hold off
[linepar,acc,outcurves]=houghline(edgecurves,grad,nrho,ntheta,gradmagnthreshold,nlines,verbose,vote); 
% figure,overlaycurves(pic,outcurves),title('Final result'),xlim([0 size(pic,1)]),ylim([0 size(pic,2)])
end
    
