function[prob,pos]=mixture_prob(image, K, L, mask)
% Function that receives as inputs the image where to compute a
% Gaussian-mixture model with K Gaussian models. It applies a
% Maximization-Expectation algorithm through L iterations on a set of
% pixels defined by a mask.

if nargin<1 || nargin>4
    disp('Wrong number of arguments');
elseif nargin==1
    K=2;
    L=20;
    mask=ones([size(image,1) size(image,2)]);
elseif nargin==2
    L=20;
    mask=ones([size(image,1) size(image,2)]);
elseif nargin==3
    mask=ones([size(image,1) size(image,2)]);
end

% Improve computational speed by merging image channels into a 2D array and
% making mask a 1D array
Ivec=im2double(reshape(image,size(image,1)*size(image,2),3));


% Keep just those image pixels defined by the user, where mask=1
if nargin==4
    mask_vec=reshape(mask,[prod(size(mask)),1]);
    pos=find(mask_vec==1);
    Ima=Ivec(pos,:);
end

% Random initialization of means
%Ima=reshape(Ima,size());
[segm,means]=kmeans_segm(Ima,K,L,14);
%Ima=reshape(Ima,[size(image,1)*size(image,2),3]);
weights=zeros(1,K);
for j=1:K
    position=find(segm==j);
    weights(1,j)=length(position)/size(Ima,1);
end
covariances = cell(K, 1);
covariances(:) = {rand * eye(3)};

% Initialization and Expectation-Maximization algorithm
resp=zeros(size(Ima,1),K); % p(i,k) for Expectation
gaussian=zeros(size(resp)); % Cell of Gaussian distributions
diff=zeros([size(Ima) K]);

for i=1:L
    % EXPECTATION
    for j=1:K
        diff(:,:,j)=Ima-(zeros(size(Ima))+means(j,:));
        gaussian(:,j)=(1/(sqrt((2*pi)^3*det(covariances{j,1}))))*exp(-0.5*sum(diff(:,:,j)*inv(covariances{j,1}).*diff(:,:,j),2));
    end
    resp=gaussian.*(weights.*ones(size(gaussian)))./(sum(gaussian.*(weights.*ones(size(gaussian))),2));
    resp=resp+eps;
    s=sum(resp,1);
    % MAXIMIZATION
    weights=s./size(Ima,1);
    for j=1:size(Ima,2)
        means(:,j)=(sum((resp.*Ima(:,j)),1)./s)';
    end

    means=reshape(means,[prod(size(means)) 1]);
    posit=find(isnan(means)==1);
    means(posit)=0;
    means=reshape(means,[K size(Ima,2)]);
    aux=zeros(size(diff,1),size(diff,2));
    
    for j=1:K
        diff(:,:,j)=Ima-(zeros(size(Ima))+means(j,:));
        aux=(resp(:,j).*ones(size(diff(:,:,j)))).*diff(:,:,j);
        for l=1:size(Ima,2)
            covariances{j,1}(l,:)=sum((aux(:,l).*ones(size(diff(:,:,j))).*diff(:,:,j))./s(j),1);
        end
        if isnan(covariances{j,1})==1
            covariances{j,1}=eye(size(Ima,2));
        end
    end
end

%Probability computations. TAKE INTO ACCOUNT ALL PIXELS, INCLUDING
%NON-MASKED ONES!!!
gaussian1=zeros(size(Ivec,1),K);
prob=zeros(size(Ivec,1),1);
diff1=zeros([size(Ivec) K]);
for j=1:K
    diff1(:,:,j)=Ivec-(zeros(size(Ivec))+means(j,:));
    gaussian1(:,j)=(1/(sqrt((2*pi)^3*det(covariances{j,1}))))*exp(-0.5*sum(diff1(:,:,j)*inv(covariances{j,1}).*diff1(:,:,j),2));
    prob=prob+gaussian1(:,j).*weights(j);
end

end