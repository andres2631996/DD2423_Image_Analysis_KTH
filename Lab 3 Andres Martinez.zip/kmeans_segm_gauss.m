function [ segm, centers,aux ] = kmeans_segm_gauss(I, K, L, seed)

if nargin<1 || nargin>4
    disp('Wrong number of arguments');
elseif nargin==1
    K=8;
    L=20;
    seed=14;
elseif nargin==2
    L=20;
    seed=14;
elseif nargin==3
    seed=14;
end

%[width,height,channels]=size(I); %Image size
I=double(I);
s=rng(seed); % Random number generation for initializing clusters
for i=1:3
    range=max(I(:,i))-min(I(:,i));
    centers(:,i)=range*rand(K,1)+min(min((I(:,i)))); % Initial centers
end
%Ivec = double(reshape(I, width*height, channels)); % Work in 2D
d=[];
Ivec=I;
segm=zeros(size(Ivec));
aux=zeros([size(centers) L]);
aux(:,:,1)=centers;
threshold=0.0001;
i=1;
D=1;
while D>=threshold && i<L+1
    d=pdist2(Ivec,centers);
    [mina,segm]=min(d,[],2);
    for j=1:K
        pos=find(segm==j);
        if isempty(pos)==0
            centers(j,:)=mean(Ivec(pos,:));
%             segm(pos,:)=centers(j,:)+zeros(size(pos));
        end
    end
    i=i+1;
end
%segm=reshape(segm,[width,height]);
%         if i==L && isempty(pos)==0
%             segm(pos,:)=centers(j,:)+zeros(size(pos));
%         end
%     end
%     i=i+1;
%     aux(:,:,i)=centers;
%     diff=abs(aux(:,:,i)-aux(:,:,i-1));
%     D=max(diff(:));
% end
end